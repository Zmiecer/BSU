// Complex.cpp: ���������� ����� ����� ��� ����������� ����������.
//

#include <iostream>
#include <ostream>
#include <istream>
#include <conio.h>
#include <math.h>
#include "Complex.h"

using namespace std;


ostream &operator<<(ostream &out, Complex &c)
{
   out << c.re << " + I * " << c.im << "\n";
   
   return out;
}

istream &operator>>(istream &in, Complex &c)
{
   in >> c.re >> c.im;
   
   return in;
}

int main()
{
	double a,b,c,d;
	cin >> a >> b >> c >> d;
    Complex value1(a,b);
    Complex value2(c,d);
    
    cout << value1 << value2 << endl;
    cout << value1 + value2 << endl;
    cout << value1 - value2 << endl;
    cout << value1 * value2 << endl;
    cout << value1 / value2 << endl;    
    value1 = value2;
    cout << value1 << " = " << value2 << endl;

	Complex mass[20];
	int n;
	double x,y;
	cin >> n;
    for (int i=0; i<n; i++)
	{
		cin >> x >> y;
		mass[i] = Complex(x,y);
	}
	for (int i=0; i<n; i++)
	{
		cout << mass[i];
	}
    return 0;
}